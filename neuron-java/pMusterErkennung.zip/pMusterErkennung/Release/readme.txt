Die Daten werden im "Eigene Dateien" erwartet

Windows: C:\Users\Bernd\Documents
Linux:   /home/bernd/Documents