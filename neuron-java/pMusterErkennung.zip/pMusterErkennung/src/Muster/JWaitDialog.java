/*
 * Created on 19.05.2005
 */
package Muster;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Window;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 * Dem <code>JWorkDialog</code> kann eine Meldung sowie ein <code>Runnable</code>-
 * Interface übergeben werden.

 * Der Dialog zeigt die Meldung an, und führt im Hintergrund das übergebene
 * <code>Runnable</code>-Interface in einem Thread aus. Ist die Verarbeitung
 * abgeschlossen, wird der Dialog geschlossen.

 *

 * Der <code>JWaitDialog</code> eignet sich hervorragend um z.b. beim beenden
 * einer Applikation während dem speichern von daten eine kleine Meldung an-
 * zuzeigen.
 *
 * @author Manuel Alabor
 * @author thanks for tips & help: Thomas Myrberg @ [url]http://forum.java.sun.com/[/url]
 * @version 1.0
 */
public class JWaitDialog extends JDialog {

    /* GUI-Komponenten: */
    private JLabel lblMessage = new JLabel();
   
    /* Objekte: */
    private Runnable workToDo;
   
    /**
     * Standartkonstruktor.
     *
     * @param owner "Besitzer" des Dialoges
     * @param message Nachricht
     * @param work Auszuführender Code in einem Runnable-Interface
     */
    
    public JWaitDialog(JFrame owner, String message, Runnable work) {
        /* Initialisieren: */
        super(owner);
       
        /* Werte übernehmen: */
        lblMessage.setText(message);
        this.workToDo = work;
       
        /* WindowListener erstellen: */
        addWindowListener(new WindowListener());
       
        /* GUI initialisieren: */
        initGui();
    }
   
    	
	// Initialisierung ---------------------------------------------------------
    /**
     * Initialisiert das GUI.
     */
    private void initGui() {
        /* Vorbereiten: */
        JPanel contentPane = (JPanel)getContentPane();
       
        /* Dialog anpassen: */
        setResizable(false);
        setSize(250,60);
        setUndecorated(true);
        setModal(true);
       
        /* Message anpassen: */
        lblMessage.setHorizontalAlignment(JLabel.CENTER);
        lblMessage.setBorder(BorderFactory.createRaisedBevelBorder());
       
        /* Message anordnen: */
        contentPane.setLayout(new BorderLayout());
        contentPane.add(lblMessage, BorderLayout.CENTER);
    }
   
   
    // Überschreibungen --------------------------------------------------------
    /**
     * show-Methode überschreiben damit JWaitDialog immer zentriert auf
     * owner angezeigt wird.
     */
    public void show() {
        Component owner = getOwner();
       
        Dimension d = owner.getSize();
        Point p = owner.getLocation();
        setLocation(((d.width - getWidth()) / 2) + p.x, ((d.height - getHeight()) / 2) +p.y);
       
        super.show();
    }
   
    // Hilfsklassen ------------------------------------------------------------
    /**
     * Dieser <code>WindowListener</code> führt beim anzeigen den Code in
     * <code>workToDo</code> als Thread aus. Nachdem der Code abgearbeitet wurde,
     * wird der Dialog automatisch geschlossen.
     *
     * @author Manuel Alabor
     */
    private class WindowListener extends WindowAdapter {
        public void windowOpened(WindowEvent arg0) {
            /* Thread erstellen: */
            WorkerThread worker = new WorkerThread(workToDo, JWaitDialog.this);
           
            /* Thread starten: */
            worker.start();
        }
    }
   
    /**
     * <code>WorkerThread</code> ermöglicht das Ausführen des <code>workToDo</code>-
     * Codes und das anschliessende schliessen eines Fensters.
     *
     * @author Manuel Alabor
     */
    private class WorkerThread extends Thread {
       
        /* Eigenschaften: */
        private Runnable workToDo;
        private Window toDispose;
       
        /**
         * Standartkonstruktor.
         *
         * @param workToDo Runnable-Interface mit auszuführendem Code
         * @param toDispose zu schliessendes Fenster
         */
        public WorkerThread(Runnable workToDo, Window toDispose) {
            this.workToDo = workToDo;
            this.toDispose = toDispose;
        }
       
        /**
         * Führt den im Runnable-Interface enthaltenen Code aus und schliesst
         * das entsprechende Fenster.
         */
        public void run() {
            /* workToDo ausführen: */
            workToDo.run();
           
            /* Fenster schliessen: */
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    toDispose.dispose();
                }
            });
        }
       
    }
   
}