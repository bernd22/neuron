﻿package Muster;

import javax.swing.*;

public class Main extends JFrame
{
   public static void main( String[] args )
  {
    MusterFrame c = new MusterFrame();
    c.Show();
  }
}
