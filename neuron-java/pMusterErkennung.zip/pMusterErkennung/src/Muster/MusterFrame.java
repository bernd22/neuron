﻿package Muster;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Random;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;

import Neuronen.Neuronen;

public class MusterFrame extends JFrame implements ActionListener, ChangeListener
{
  private final int ZEILEN        = 5;
  private final int SPALTEN       = 5;
  private final int ANZAHL_MUSTER = 10;
  private final int PUNKTE_MUSTER = ZEILEN * SPALTEN;
  private final int HOEHE         = 20;
  private final int BREITE        = 20;

  private String          homeuser  = System.getProperty( "user.home" ) + "/documents/";
  private File            fcFile;
  private enum            fileOperation
  {
	  NN_MUSTER_LESEN, NN_MUSTER_SICHERN, NN_WISSEN_LESEN, NN_WISSEN_SICHERN 
  }

  
  private double[][]       werte         = new double[ANZAHL_MUSTER + 1][PUNKTE_MUSTER];

  private JButton[]        eingabe       = new JButton[ANZAHL_MUSTER * PUNKTE_MUSTER];
  private JButton[]        test          = new JButton[PUNKTE_MUSTER];
  private JButton[]        ausgabe       = new JButton[PUNKTE_MUSTER];

  private JButton          btnErkennen, btnLernen, 
                           btnAbout, btnMusterLesen, btnMusterSichern, btnWissenLesen, btnWissenSichern;

  private JTextField       tfStatus;
  private JSlider          slZufall, slKopieren;
  private JLabel           lbDymmy;

  private Neuronen         nn;
  private double[][]       nnMuster      = new double[ANZAHL_MUSTER][PUNKTE_MUSTER];
  private double[][]       nnTest        = new double[1][PUNKTE_MUSTER];
  private double[][]       nnOutput      = new double[1][PUNKTE_MUSTER];
  private int[]            nnIdent       = new int[1];
  private int[][]          nnHamming     = new int[1][ANZAHL_MUSTER];
  private int[]            nnHammingMin  = new int[1];
  private char[][]         nnGrau        = new char[1][ANZAHL_MUSTER];

  Random             r                 = new Random( System.currentTimeMillis() );
  
  private int f( int i )
  {
    int retVal = 0;
    retVal = ( i / PUNKTE_MUSTER ) * PUNKTE_MUSTER + ( ( i * ( SPALTEN - 1 ) ) % PUNKTE_MUSTER );
    return retVal;
  }

  public MusterFrame()
  {
    nn = new Neuronen( PUNKTE_MUSTER, 10, ANZAHL_MUSTER, 1 );
    initializeComponent();
  }

  void Show()
  {
    initFrame();
    this.setVisible( true );
  }

  private void initFrame()
  {

  }

  private void initializeComponent()
  {
    this.setTitle( "Muster" );
    this.setBounds( 100, 100, 800, 600 );
    this.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    this.setResizable( false );
    this.setLayout( null );

    for ( int i = 0; i < eingabe.length; i++ )
    {
      eingabe[f( i )] = erzeuge( i, 25, 25, false );
    }

    for ( int i = 0; i < test.length; i++ )
    {
      test[f( i )] = erzeuge( i, 25, 350, false );
    }

    for ( int i = 0; i < test.length; i++ )
    {
      ausgabe[f( i )] = erzeuge( i, 160, 350, true );
    }

    btnLernen = new JButton( "Lernen" );
    btnLernen.setBounds( 590, 355, 175, 25 );
    btnLernen.setMnemonic( KeyEvent.VK_L );
    btnLernen.addActionListener( this );
    this.add( btnLernen );

    btnErkennen = new JButton( "Erkennen" );
    btnErkennen.setBounds( 590, 405, 175, 25 );
    btnErkennen.setMnemonic( KeyEvent.VK_E );
    btnErkennen.addActionListener( this );
    this.add( btnErkennen );

    btnAbout = new JButton( "Über" );
    btnAbout.setBounds( 25, 515, 125, 25 );
    btnAbout.setMnemonic( KeyEvent.VK_A );
    btnAbout.addActionListener( this );
    this.add( btnAbout );

    btnMusterLesen = new JButton( "Muster" );
    btnMusterLesen.setBounds( 175, 515, 125, 25 );
    btnMusterLesen.setMnemonic( KeyEvent.VK_M );
    btnMusterLesen.addActionListener( this );
    this.add( btnMusterLesen );

    btnMusterSichern = new JButton( "Sichern M" );
    btnMusterSichern.setBounds( 325, 515, 125, 25 );
    btnMusterSichern.setMnemonic( KeyEvent.VK_S );
    btnMusterSichern.addActionListener( this );
    this.add( btnMusterSichern );

    btnWissenLesen = new JButton( "Wissen" );
    btnWissenLesen.setBounds( 475, 515, 125, 25 );
    btnWissenLesen.setMnemonic( KeyEvent.VK_W );
    btnWissenLesen.addActionListener( this );
    this.add( btnWissenLesen );

    btnWissenSichern = new JButton( "Sichern W" );
    btnWissenSichern.setBounds( 625, 515, 125, 25 );
    btnWissenSichern.setMnemonic( KeyEvent.VK_I );
    btnWissenSichern.addActionListener( this );
    this.add( btnWissenSichern );

    slZufall = new JSlider( JSlider.HORIZONTAL, 0, ANZAHL_MUSTER, 0 );
    slZufall.setBounds( 355, 350, 200, 50 );
    slZufall.setMajorTickSpacing( 1 );
    slZufall.setPaintTicks( true );
    slZufall.setPaintLabels( true );
    slZufall.addChangeListener( this );
    this.add( slZufall );  
    
    slKopieren = new JSlider( JSlider.HORIZONTAL, 0, ANZAHL_MUSTER, 0 );
    slKopieren.setBounds( 355, 430, 200, 50 );
    slKopieren.setMajorTickSpacing( 1 );
    slKopieren.setPaintTicks( true );
    slKopieren.setPaintLabels( true );
    slKopieren.addChangeListener( this );
    this.add( slKopieren );  
    
    tfStatus = new JTextField();
    tfStatus.setBounds( 590, 460, 175, 25 );
    tfStatus.setMargin( new Insets( 2, 2, 2, 2) );
    this.add( tfStatus );

    lbDymmy = new JLabel( "Test" );
    lbDymmy.setBounds( 50, 470, 50, 25 );
    this.add( lbDymmy );

    lbDymmy = new JLabel( "Ergebnis" );
    lbDymmy.setBounds( 175, 470, 70, 25 );
    this.add( lbDymmy );
 
    lbDymmy = new JLabel( "Zufällig" );
    lbDymmy.setBounds( 290, 350, 70, 25 );
    this.add( lbDymmy );
 
    lbDymmy = new JLabel( "Kopie" );
    lbDymmy.setBounds( 305, 430, 50, 25 );
    this.add( lbDymmy );
 }

  private JButton erzeuge( int n, int offx, int offy, boolean readonly )
  {
    JButton button = new JButton();
    button.setName( String.valueOf( f( n ) ) );
    button.setBackground( Color.WHITE );
    int absx = offx + ( n / PUNKTE_MUSTER ) * ( ( SPALTEN + 1 ) * BREITE ) + ( n % SPALTEN ) * BREITE;
    int absy = offy + ( n / SPALTEN ) * HOEHE - ( n / PUNKTE_MUSTER ) * ( ZEILEN * HOEHE );
    if ( n >= PUNKTE_MUSTER * 5)
    {
    	absx -= 5 * (SPALTEN + 1 ) * BREITE;
    	absy += (ZEILEN + 1 ) * HOEHE;
    }
    button.setBounds( absx, absy, BREITE, HOEHE );
    button.setFocusable( !readonly );
    button.setEnabled( !readonly );
    //button.setBorder( null );
    button.addActionListener( this );
    this.add( button );
    return button;
  }

  @Override
  public void actionPerformed( ActionEvent e )
  {
    JButton b = (JButton)e.getSource();
    if ( b.equals( btnErkennen ) )
      erkennen();
    else if ( b.equals( btnLernen ) )
      lernenMitFenster();
    else if ( b.equals( btnAbout ) )
      meldung( "Mustererkennung mit einem Neuronalen Netz \n\n" +
               "Projektarbeit von  Bernd Schubert, Alfatraining Rostock\n\n" +
	           "aus dem Java-Kurs bei Herrn König,  12.01.2015 - 06.03.2015\n\n" );
    else if ( b.equals( btnMusterLesen ) )
        musterLesen();
    else if ( b.equals( btnMusterSichern ) )
        musterSichern();
    else if ( b.equals( btnWissenLesen ) )
        wissenLesen();
    else if ( b.equals( btnWissenSichern ) )
        wissenSichern();
    else
      setzen( b );
  }

  private void setzen( JButton b )
  {
    //System.out.println( "Ich bin " + b.getName() );
    if ( b.getBackground().equals( Color.BLACK ) )
      b.setBackground( Color.LIGHT_GRAY );
    else if ( b.getBackground().equals( Color.LIGHT_GRAY ) )
      b.setBackground( Color.WHITE );
    else if ( b.getBackground().equals( Color.WHITE ) )
      b.setBackground( Color.BLACK );
    
    auslesen();
  }

  private void kopieren( int i, JButton[] feld )
  {
    scanMuster( 0, eingabe, ( i - 1 ) * PUNKTE_MUSTER );
    putMuster( 0, feld, 0 );
    
    auslesen();
  }

  private double zufallsZahl()
  {
    return r.nextInt(2) * 1.0;
  }
  
  private void zufall( int i )
  {
    for ( int j = 0; j < werte[i].length; j++ )
    {
      werte[i][j] = zufallsZahl();
    }
    putMuster( i, eingabe, ( i - 1 ) * PUNKTE_MUSTER );
    auslesen();
  }

  private void erkennen()
  {
    scanMuster( 0, test, 0 );
    //kontrolleWerte( 0 );
    for ( int i = 1; i <= ANZAHL_MUSTER; i++ )
    {
      scanMuster( i, eingabe, ( i - 1 ) * PUNKTE_MUSTER );
      //kontrolleWerte( i );
    }

    nn.erkennen();
    nnOutput=nn.getErgebnisOutput();
    nnIdent=nn.getErgebnisIdent();
    nnHamming=nn.getHamming();
    nnHammingMin=nn.getHammingMin();
    nnGrau=nn.getErgebnisGrau();
    
    for ( int j = 0; j < PUNKTE_MUSTER; j++ )
    {
      werte[0][j] = nnOutput[0][j];
    }
    putMuster( 0, ausgabe, 0 );

    if(nnIdent[0] > -1)
      tfStatus.setText( " Erkenne Muster: " + (nnIdent[0] + 1) );
    else if (nnHammingMin[0] > -1)
      tfStatus.setText( " Tippe auf Muster: " + (nnHammingMin[0] + 1) );
    else 
      tfStatus.setText( "Kein Muster erkennbar?" );

    nn.analyse();
  }

  private void lernenMitFenster()
  {
	  Runnable work = new Runnable() {
  
	  public void run() {
		    lernen();
		  };
	  };
	
	  JWaitDialog dlg = new JWaitDialog(this, "Lernen :-)  Bitte warten...", work);
	  dlg.show();
  }
  
  private void lernen()
  {
	DecimalFormat f = new DecimalFormat( "#0.00000000" );
    nn.setAktSchritt( 0 );
    nn.lernSchritt();
    System.out.println( "vor Lernen Schritt:" + nn.getAktSchritt() + " von " + nn.getSchritteError()
        + " Fehler:" + nn.getAktError() );
    tfStatus.setText( " Fehler: " + f.format( nn.getAktError() ) );
    while ( nn.getAktError() > nn.getStopError() && nn.getAktSchritt() < nn.getSchritteError() )
    {
      nn.lernSchritt();
      if ( nn.getAktSchritt() % 1000 == 0 )
        System.out.println( "im Lernen Schritt:" + nn.getAktSchritt() + " von " + nn.getSchritteError()
            + " Fehler:" + nn.getAktError() );
      tfStatus.setText( " Fehler: " + f.format( nn.getAktError() ) );
    }
    System.out.println( "nach Lernen Schritt:" + nn.getAktSchritt() + " von " + nn.getSchritteError()
        + " Fehler:" + nn.getAktError() );
    tfStatus.setText( " Fehler: " + f.format( nn.getAktError() ) );
  }

  private void kontrolleWerte( int n )
  {
    System.out.print( "Werte[" + n + "]=" );
    for ( int i = 0; i < PUNKTE_MUSTER; i++ )
    {
      System.out.print( werte[n][i] + "," );
    }
    System.out.println();
  }

  private void scanMuster( int pos, JButton[] feld, int start )
  {
    for ( int i = 0; i < PUNKTE_MUSTER; i++ )
    {
      werte[pos][i] = getWert( feld[start + i] );
    }
  }

  private void putMuster( int pos, JButton[] feld, int start )
  {
    for ( int i = 0; i < PUNKTE_MUSTER; i++ )
    {
      feld[start + i].setBackground( setWert(1, werte[pos][i] ) );
    }
  }

  private double getWert( JButton jButton )
  {
    if ( jButton.getBackground().equals( Color.BLACK ) )
      return 1.0;
    if ( jButton.getBackground().equals( Color.WHITE ) )
      return 0.0;
    return 0.5;
  }

  private Color setWert( int art, double d )
  {
    if ( d > 0.90 )
      switch ( art )
      {
        case 1:
          return Color.BLACK;
        case 2:
          return Color.BLUE;
        case 3:
          return Color.GREEN;
      }
    if ( d < 0.10 )
      return Color.WHITE;
    return Color.LIGHT_GRAY;
  }

  private void auslesen()
  {
    scanMuster( 0, test, 0 );
    //kontrolleWerte( 0 );
    for ( int i = 1; i <= ANZAHL_MUSTER; i++ )
    {
      scanMuster( i, eingabe, ( i - 1 ) * PUNKTE_MUSTER );
      //kontrolleWerte( i );
    }
    for ( int i = 1; i <= ANZAHL_MUSTER; i++ )
    {
      for ( int j = 0; j < PUNKTE_MUSTER; j++ )
      {
        nnMuster[i - 1][j] = werte[i][j];
      }
    }
    for ( int j = 0; j < PUNKTE_MUSTER; j++ )
    {
      nnTest[0][j] = werte[0][j];
    }
    nn.setMuster( nnMuster );
    nn.setTest( nnTest );
  }
  
  private void lesen(String dateiname)
  {
	FileReader rd = null;
	BufferedReader br = null;
	String zeile = "";
	String[] buffer = null;

	try
	{
	  rd = new FileReader( dateiname );
	  br = new BufferedReader( rd );

	  for ( int i = 0; i <= ANZAHL_MUSTER; i++ )
	  {
	    zeile = br.readLine();
	    buffer = zeile.split( ";" );
	    for ( int k = 0; k < PUNKTE_MUSTER; k++ )
	      werte[i][k] = Double.parseDouble( buffer[k] );
	  }
	}
	catch ( IOException e )
	{
	  System.err.println( "IO-Fehler beim Öffnen/Lesen " + e.getMessage() );
	  System.err.println( "Dateiname: " + dateiname );
	}
	catch ( Exception e )
	{
	  System.err.println( "allgemeiner Fehler beim Lesen " + e.getMessage() );
	  System.err.println( "Dateiname: " + dateiname );
	}
	finally
	{
	  try
	  {
	    br.close();
	  }
	  catch ( IOException e )
	  {
	    System.err.println( "IO-Fehler beim Close " + e.getMessage() );
	    System.err.println( "Dateiname: " + dateiname );
	  }
	}

	putMuster( 0, test, 0 );
    for ( int i = 1; i <= ANZAHL_MUSTER; i++ )
    {
      putMuster( i, eingabe, ( i - 1 ) * PUNKTE_MUSTER );
    }
    
    scanMuster( 0, test, 0 );
    auslesen();
  }
  
  private void schreiben(String dateiname)
  {
    scanMuster( 0, test, 0 );
    for ( int i = 1; i <= ANZAHL_MUSTER; i++ )
    {
      scanMuster( i, eingabe, ( i - 1 ) * PUNKTE_MUSTER );
    }

    FileWriter wr = null;
    BufferedWriter bw = null;
    String zeile = "";

    try
    {
      wr = new FileWriter( dateiname );
      bw = new BufferedWriter( wr );

      for ( int i = 0; i <= ANZAHL_MUSTER; i++ )
      {
        for ( int k = 0; k < PUNKTE_MUSTER; k++ )
          zeile = zeile + werte[i][k] + ";";
        bw.write( zeile );
        bw.newLine();
        zeile = "";
      }
    }

    catch ( IOException e )
    {
      System.err.println( "IO-Fehler beim Öffnen/Schreiben " + e.getMessage() );
      System.err.println( "Dateiname: " + dateiname );
    }
    catch ( Exception e )
    {
      System.err.println( "allgemeiner Fehler beim Schreiben " + e.getMessage() );
      System.err.println( "Dateiname: " + dateiname );
    }
    finally
    {
      try
      {
        bw.close();
      }
      catch ( IOException e )
      {
        System.err.println( "IO-Fehler beim Close " + e.getMessage() );
        System.err.println( "Dateiname: " + dateiname );
      }
    }
  }
  
  @Override
  public void stateChanged( ChangeEvent e )
  {
    if (!(e.getSource() instanceof JSlider))
      return;
    JSlider sl = (JSlider)e.getSource();
    if (sl.getValueIsAdjusting())
      return;
    
    if (sl.equals( slKopieren ) &&
    	sl.getValue() > 0)
      kopieren( sl.getValue(), test );
    
    else if (sl.equals( slZufall ) &&
    	     sl.getValue() > 0)
      zufall( (int)sl.getValue() );
  }

  private void meldung( String satz )
  {
    JOptionPane.showMessageDialog(
        this,
        satz,
        "Kuchenbasar",
        JOptionPane.ERROR_MESSAGE
        );
  }

  private void musterLesen()
  {
	openFileDialog( fileOperation.NN_MUSTER_LESEN);
	nn.lernSchritt();
    DecimalFormat f = new DecimalFormat( "#0.00000000" );
	tfStatus.setText( " Fehler: " + f.format( nn.getAktError() ) );
  }

  private void musterSichern()
  {
    openFileDialog( fileOperation.NN_MUSTER_SICHERN);
  }

  private void wissenLesen()
  {
	openFileDialog( fileOperation.NN_WISSEN_LESEN);
    nn.lernSchritt();
	DecimalFormat f = new DecimalFormat( "#0.00000000" );
    tfStatus.setText( " Fehler: " + f.format( nn.getAktError() ) );
  }

  private void lesenNetz( String dateiname)
  {
  	nn.wissenLesen( dateiname );
  	scanMuster( 0, test, 0 );
  	auslesen();
  }
  
  private void schreibenNetz( String dateiname)
  {
  	nn.wissenSchreiben( dateiname );
  }
  
  private void wissenSichern()
  {
    openFileDialog( fileOperation.NN_WISSEN_SICHERN);
  }
  
  private void openFileDialog( fileOperation operation )
  {
    String dateiname;
    JFileChooser fc = new JFileChooser(homeuser);
    //fc.setCurrentDirectory( fcFile );

    if ( operation == fileOperation.NN_WISSEN_LESEN || 
         operation == fileOperation.NN_WISSEN_SICHERN )
      fc.setFileFilter( new FileNameExtensionFilter( "Wissen (*.wissen)", "wissen" ) );
    else
      fc.setFileFilter( new FileNameExtensionFilter( "Muster (*.muster)", "muster" ) );

    fc.setMultiSelectionEnabled( false );
    fc.setAcceptAllFileFilterUsed( false );

    if ( fc.showOpenDialog( this ) != JFileChooser.APPROVE_OPTION )
      return;

    fcFile = fc.getSelectedFile();
    dateiname = fcFile.toString();

    if ( dateiname.indexOf( "." ) < 0 )
      if ( operation == fileOperation.NN_WISSEN_LESEN || 
           operation == fileOperation.NN_WISSEN_SICHERN )
        dateiname += ".wissen";
      else  
    	dateiname += ".muster";

    if ( operation == fileOperation.NN_WISSEN_LESEN )
      lesenNetz( dateiname );
    else if ( operation == fileOperation.NN_WISSEN_SICHERN )
      schreibenNetz( dateiname );
    else if ( operation == fileOperation.NN_MUSTER_LESEN )
      lesen( dateiname );
    else if ( operation == fileOperation.NN_MUSTER_SICHERN )
      schreiben( dateiname );
  }

}
