﻿package Neuronen;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

/**
 * 
 * @author Bernd Schubert
 *
 */
public class Neuronen
{
  //variable Werte
  private String     wissenDateiName  = System.getProperty( "user.home" ) + "/documents/" + "propagate.txt";

  private int        inputAnz          = 25;
  private int        hiddenAnz         = 10;
  private int        musterAnz         = 4;
  private int        testAnz           = 4;

  private double     alpha             = 0.7;
  private double     eta               = 0.8;
  private double     aktError          = 0.0;
  private double     stopError         = 0.01;
  private int        schritteError     = 100000;
  private int        aktSchritt        = 0;
  private double     minimalWert       = 0.4;
  private double     abstandWert       = 0.1;

  // Output-Muster in Java (Pascal)
  //  0-3  (1-4)   musterAnz zur Identifizierung
  //  4-28 (5-29)  inputAnz  zur Mustervervollständigung
  private int        outputAnz         = musterAnz + inputAnz;
  private int        testStart         = musterAnz;

  //feste (maximale) Werte und Neuronales Netzwerk

  // Iput-Vektor in Java (Pascal)
  // 0-3  (1-4)    musterAnz gelernte Muster
  // 4-7  (5-8)    testAnz   Testmuster
  private final int  INPUT_MAX         = 100;
  private final int  HIDDEN_MAX        = 70;

  private final int  MUSTER_MAX        = 100;
  private final int  TEST_MAX          = 100;
  private final int  OUTPUT_MAX        = MUSTER_MAX + INPUT_MAX;

  //Da zu jedem Zeitpunkt sichergestellt ist, daß input, hidden, muster und test Anz
  //niemals größer als input, hidden, muster und test Max werden können
  //wird immer das komplette Netz initialisiert, in die CheckSumme einbezogen und
  //per File gelesen/geschrieben! (sowie angezeigt).
  //Das erhöht die Stabilität! Z.B. Kann das Wissensfile immer gelesen werden,
  //unabhängig davon, welche aktuellen input, hidden, muster und test Anz gesetzt sind
  //Dies könnte man sich bei Einführung dynamischer Arrays vergeben, wenn diese durch 
  //größere Zahlen notwendig werden.

  //Die eigentliche Erkennung erfolgt stets nur im aktuellen Ausschnitt des neuronalen
  //Netzwerkes, welches durch input, hidden, muster und test Anz abgesteckt wird und
  //nicht in dem, was technisch möglich wäre durch die Array-Grenzen. Daher ist es auch
  //wichtig, daß sich das aufrufende Programm an die Getter-Werte von input, hidden, 
  //muster und test Anz hält

  private double[][] layerTarget       = new double[MUSTER_MAX][OUTPUT_MAX];
  private double[][] layerInput        = new double[MUSTER_MAX + TEST_MAX][INPUT_MAX];
  private double[]   layerHidden       = new double[HIDDEN_MAX];
  private double[]   offHidden         = new double[HIDDEN_MAX];
  private double[]   diffOffHidden     = new double[HIDDEN_MAX];
  private double[]   layerOutput       = new double[OUTPUT_MAX];
  private double[]   offOutput         = new double[OUTPUT_MAX];
  private double[]   diffOffOutput     = new double[OUTPUT_MAX];
  private double[][] wInputHidden      = new double[HIDDEN_MAX][INPUT_MAX];
  private double[][] wDiffInputHidden  = new double[HIDDEN_MAX][INPUT_MAX];
  private double[][] wHiddenOutput     = new double[OUTPUT_MAX][HIDDEN_MAX];
  private double[][] wDiffHiddenOutput = new double[OUTPUT_MAX][HIDDEN_MAX];

  private double[][] musterOutput      = new double[TEST_MAX][OUTPUT_MAX];
  private int[][]    musterHamming     = new int[TEST_MAX][MUSTER_MAX];
  private int[]      musterHammingMin  = new int[TEST_MAX];
  private int[]      musterIdentFirst  = new int[TEST_MAX];
  private int[]      musterIdentSecond = new int[TEST_MAX];
  private double[]   musterWertFirst   = new double[TEST_MAX];
  private double[]   musterWertSecond  = new double[TEST_MAX];

  private double[][] ergebnisOutput    = new double[TEST_MAX][INPUT_MAX];
  private char[][]   ergebnisGrau      = new char[TEST_MAX][INPUT_MAX];
  private int[]      ergebnisIdent     = new int[TEST_MAX];

  Random             r                 = new Random( System.currentTimeMillis() );

  public Neuronen()
  {
    initLeer();
  }

  /**
   * 
   * @param inputAnz
   * @param hiddenAnz
   * @param musterAnz
   * @param testAnz
   */
  public Neuronen( int inputAnz, int hiddenAnz, int musterAnz, int testAnz )
  {
    setInputAnz( inputAnz );
    setHiddenAnz( hiddenAnz );
    setMusterAnz( musterAnz );
    setTestAnz( testAnz );
    initLeer();
    initStart();
  }

  public int getMusterAnz()
  {
    return musterAnz;
  }

  public void setMusterAnz( int musterAnz )
  {
    if ( musterAnz > 0 && musterAnz <= MUSTER_MAX )
    {
      this.musterAnz = musterAnz;
      testStart = musterAnz;
      setOutputAnz( inputAnz + musterAnz );
    }
  }

  public int getInputAnz()
  {
    return inputAnz;
  }

  public void setInputAnz( int inputAnz )
  {
    if ( inputAnz > 0 && inputAnz <= INPUT_MAX )
    {
      this.inputAnz = inputAnz;
      setOutputAnz( inputAnz + musterAnz );
    }
  }

  public int getHiddenAnz()
  {
    return hiddenAnz;
  }

  public void setHiddenAnz( int hiddenAnz )
  {
    if ( hiddenAnz > 0 && hiddenAnz <= HIDDEN_MAX )
      this.hiddenAnz = hiddenAnz;
  }

  public int getOutputAnz()
  {
    return outputAnz;
  }

  //da der Algorithmus auf Vervollständigung und Identifizierung
  //erfordert, daß Output-Anzahl = Input-Anzahl + Muster-Anzahl gilt,
  //ist dieser Setter aus Sicherheitsgründen nach außen hin deaktiviert
  //setInputAnz und SetMusterAnz aktualisieren ggf. die Output-Anzahl mit 
  private void setOutputAnz( int outputAnz )
  {
    if ( outputAnz > 0 && outputAnz <= OUTPUT_MAX )
      this.outputAnz = outputAnz;
  }

  public int getTestAnz()
  {
    return testAnz;
  }

  public void setTestAnz( int testAnz )
  {
    if ( testAnz > 0 && testAnz <= TEST_MAX )
      this.testAnz = testAnz;
  }

  public double getAlpha()
  {
    return alpha;
  }

  public void setAlpha( double alpha )
  {
    if ( alpha > 0.0 && alpha < 1.0 )
      this.alpha = alpha;
  }

  public double getEta()
  {
    return eta;
  }

  public void setEta( double eta )
  {
    if ( eta > 0.0 && eta < 1.0 )
      this.eta = eta;
  }

  public double getAktError()
  {
    return aktError;
  }

  public void setAktError( double aktError )
  {
    if ( aktError > 0.0 && aktError < 10.0 )
      this.aktError = aktError;
  }

  public double getStopError()
  {
    return stopError;
  }

  public void setStopError( double stopError )
  {
    if ( stopError > 0.0 && stopError < 10.0 )
      this.stopError = stopError;
  }

  public int getSchritteError()
  {
    return schritteError;
  }

  public void setSchritteError( int schritteError )
  {
    if ( schritteError > 0 && schritteError < 20000000 )
      this.schritteError = schritteError;
  }

  public int getAktSchritt()
  {
    return aktSchritt;
  }

  public void setAktSchritt( int aktSchritt )
  {
    if ( aktSchritt >= 0 && aktSchritt < this.schritteError )
      this.aktSchritt = aktSchritt;
  }

  public double getAbstandWert()
  {
    return abstandWert;
  }

  public void setAbstandWert( double abstandWert )
  {
    if ( abstandWert > 0.1 && abstandWert < 0.9 )
      this.abstandWert = abstandWert;
  }

  public double getMinimalWert()
  {
    return minimalWert;
  }

  public void setMinimalWert( double minimalWert )
  {
    if ( minimalWert > 0.1 && minimalWert < 0.9 )
      this.minimalWert = minimalWert;
  }

  public void setMuster( double[][] feld )
  {
    for ( int i = 0; i < musterAnz; i++ )
      for ( int j = 0; j < inputAnz; j++ )
      {
        layerInput[i][j] = feld[i][j];
        layerTarget[i][j + testStart] = feld[i][j];
      }
  }

  public void setGrauMuster( char[][] feld )
  {
    setMuster( grau2doubleFeld( feld ) );
  }

  public void setTest( double[][] feld )
  {
    for ( int i = 0; i < musterAnz; i++ )
    {
      for ( int j = 0; j < musterAnz; j++ )
      {
        if ( i == j )
          layerTarget[i][j] = 0.9;
        else
          layerTarget[i][j] = 0.1;
      }
    }
    for ( int i = 0; i < testAnz; i++ )
      for ( int j = 0; j < inputAnz; j++ )
        layerInput[i + testStart][j] = feld[i][j];
  }

  public void setGrauTest( char[][] feld )
  {
    setTest( grau2doubleFeld( feld ) );
  }

  public double getCheckSumme()
  {
    double summe = 0.0;
    for ( int i = 0; i < layerTarget.length; i++ )
      for ( int k = 0; k < layerTarget[0].length; k++ )
        summe += layerTarget[i][k];
    for ( int i = 0; i < layerInput.length; i++ )
      for ( int k = 0; k < layerInput[0].length; k++ )
        summe += layerInput[i][k];
    for ( int i = 0; i < wInputHidden.length; i++ )
      for ( int k = 0; k < wInputHidden[0].length; k++ )
        summe += wInputHidden[i][k];
    for ( int i = 0; i < wDiffInputHidden.length; i++ )
      for ( int k = 0; k < wDiffInputHidden[0].length; k++ )
        summe += wDiffInputHidden[i][k];
    for ( int i = 0; i < wHiddenOutput.length; i++ )
      for ( int k = 0; k < wHiddenOutput[0].length; k++ )
        summe += wHiddenOutput[i][k];
    for ( int i = 0; i < wDiffHiddenOutput.length; i++ )
      for ( int k = 0; k < wDiffHiddenOutput[0].length; k++ )
        summe += wDiffHiddenOutput[i][k];
    for ( int i = 0; i < layerHidden.length; i++ )
      summe += layerHidden[i];
    for ( int i = 0; i < offHidden.length; i++ )
      summe += offHidden[i];
    for ( int i = 0; i < diffOffHidden.length; i++ )
      summe += diffOffHidden[i];
    for ( int i = 0; i < layerOutput.length; i++ )
      summe += layerOutput[i];
    for ( int i = 0; i < offOutput.length; i++ )
      summe += offOutput[i];
    for ( int i = 0; i < diffOffOutput.length; i++ )
      summe += diffOffOutput[i];

    return summe;
  }

  public int[][] getHamming()
  {
    int dist;
    for ( int i = 0; i < testAnz; i++ )
    {
      for ( int j = 0; j < musterAnz; j++ )
      {
        dist = 0;
        for ( int k = 0; k < inputAnz; k++ )
        {
          if ( zahl2grau( layerInput[i + testStart ][k] ) != zahl2grau( layerInput[j][k] ) )
            dist++;
        }
        musterHamming[i][j] = dist;
      }
    }
    return musterHamming;
  }

  public int[] getHammingMin()
  {
    int dist;
    for ( int i=0; i < testAnz; i++)
    {
      musterHammingMin[i]=-1;
      dist = inputAnz;
      for ( int j = 0; j < musterAnz; j++ )
      {
        if(musterHamming[i][j] < dist)
        {
          dist = musterHamming[i][j];
          musterHammingMin[i] = j;
        }
      }
    }
    return musterHammingMin;
  }

  public double[][] getErgebnisOutput()
  {
    return ergebnisOutput;
  }

  public char[][] getErgebnisGrau()
  {
    return ergebnisGrau;
  }

  public int[] getErgebnisIdent()
  {
    return ergebnisIdent;
  }

  public void reset()
  {
    initLeer();
  }

  public void zufall()
  {
    initZufall();
  }

  /**
   * Diese Methode ist für den Erkennprozeß wichtig. Die Gewichte für den Backpropagation-Prozeß
   * werden zufällig besetzt Blieben diese null, läuft das Lernen eine Endlosschleife
   */
  public void start()
  {
    initStart();
  }

  public void initLeer()
  {
    for ( int i = 0; i < layerTarget.length; i++ )
      for ( int k = 0; k < layerTarget[0].length; k++ )
        layerTarget[i][k] = 0.0;
    for ( int i = 0; i < layerInput.length; i++ )
      for ( int k = 0; k < layerInput[0].length; k++ )
        layerInput[i][k] = 0.0;
    for ( int i = 0; i < wInputHidden.length; i++ )
      for ( int k = 0; k < wInputHidden[0].length; k++ )
        wInputHidden[i][k] = 0.0;
    for ( int i = 0; i < wDiffInputHidden.length; i++ )
      for ( int k = 0; k < wDiffInputHidden[0].length; k++ )
        wDiffInputHidden[i][k] = 0.0;
    for ( int i = 0; i < wHiddenOutput.length; i++ )
      for ( int k = 0; k < wHiddenOutput[0].length; k++ )
        wHiddenOutput[i][k] = 0.0;
    for ( int i = 0; i < wDiffHiddenOutput.length; i++ )
      for ( int k = 0; k < wDiffHiddenOutput[0].length; k++ )
        wDiffHiddenOutput[i][k] = 0.0;
    for ( int i = 0; i < layerHidden.length; i++ )
      layerHidden[i] = 0.0;
    for ( int i = 0; i < offHidden.length; i++ )
      offHidden[i] = 0.0;
    for ( int i = 0; i < diffOffHidden.length; i++ )
      diffOffHidden[i] = 0.0;
    for ( int i = 0; i < layerOutput.length; i++ )
      layerOutput[i] = 0.0;
    for ( int i = 0; i < offOutput.length; i++ )
      offOutput[i] = 0.0;
    for ( int i = 0; i < diffOffOutput.length; i++ )
      diffOffOutput[i] = 0.0;
  }

  public void initZufall()
  {
    for ( int i = 0; i < layerTarget.length; i++ )
      for ( int k = 0; k < layerTarget[0].length; k++ )
        layerTarget[i][k] = zufallsWert();
    for ( int i = 0; i < layerInput.length; i++ )
      for ( int k = 0; k < layerInput[0].length; k++ )
        layerInput[i][k] = zufallsWert();
    for ( int i = 0; i < wInputHidden.length; i++ )
      for ( int k = 0; k < wInputHidden[0].length; k++ )
        wInputHidden[i][k] = zufallsWert();
    for ( int i = 0; i < wDiffInputHidden.length; i++ )
      for ( int k = 0; k < wDiffInputHidden[0].length; k++ )
        wDiffInputHidden[i][k] = zufallsWert();
    for ( int i = 0; i < wHiddenOutput.length; i++ )
      for ( int k = 0; k < wHiddenOutput[0].length; k++ )
        wHiddenOutput[i][k] = zufallsWert();
    for ( int i = 0; i < wDiffHiddenOutput.length; i++ )
      for ( int k = 0; k < wDiffHiddenOutput[0].length; k++ )
        wDiffHiddenOutput[i][k] = zufallsWert();
    for ( int i = 0; i < layerHidden.length; i++ )
      layerHidden[i] = zufallsWert();
    for ( int i = 0; i < offHidden.length; i++ )
      offHidden[i] = zufallsWert();
    for ( int i = 0; i < diffOffHidden.length; i++ )
      diffOffHidden[i] = zufallsWert();
    for ( int i = 0; i < layerOutput.length; i++ )
      layerOutput[i] = zufallsWert();
    for ( int i = 0; i < offOutput.length; i++ )
      offOutput[i] = zufallsWert();
    for ( int i = 0; i < diffOffOutput.length; i++ )
      diffOffOutput[i] = zufallsWert();
  }

  public void initStart()
  {
    for ( int i = 0; i < hiddenAnz; i++ )
    {
      for ( int j = 0; j < outputAnz; j++ )
      {
        wDiffHiddenOutput[j][i] = 0.0;
        wHiddenOutput[j][i] = zufallsWert();
      }
      for ( int j = 0; j < inputAnz; j++ )
      {
        wDiffInputHidden[i][j] = 0.0;
        wInputHidden[i][j] = zufallsWert();
      }
    }
  }

  public void erkennen()
  {
    for ( int i = 0; i < testAnz; i++ )
    {
      ergebnisIdent[i] = -1;
      propagation( i + testStart );
      for ( int j = 0; j < outputAnz; j++ )
        musterOutput[i][j] = layerOutput[j];
      musterIdentFirst[i] = 0;
      musterIdentSecond[i] = 0;
      musterWertFirst[i] = 0.0;
      musterWertSecond[i] = 0.0;

      for ( int j = 0; j < musterAnz; j++ )
        if ( musterWertFirst[i] < layerOutput[j] )
        {
          musterWertFirst[i] = layerOutput[j];
          musterIdentFirst[i] = j;
        }
      for ( int j = 0; j < musterAnz; j++ )
        if ( musterWertSecond[i] < layerOutput[j] && j != musterIdentFirst[i] )
        {
          musterWertSecond[i] = layerOutput[j];
          musterIdentSecond[i] = j;
        }

      if ( musterWertFirst[i] > minimalWert
          && musterWertFirst[i] - musterWertSecond[i] > abstandWert )
        ergebnisIdent[i] = musterIdentFirst[i];

      for ( int j = 0; j < inputAnz; j++ )
      {
        ergebnisOutput[i][j] = musterOutput[i][j + testStart];
        ergebnisGrau[i][j] = zahl2grau( ergebnisOutput[i][j] );
      }
    }
  }

  public void lernSchleife()
  {
    aktSchritt = 0;
    aktError = fError();
    while ( aktError >= stopError && aktSchritt < schritteError )
    {
      for ( int j = 0; j < musterAnz; j++ )
      {
        propagation( j );
        backpropagation( j );
      }
      aktError = fError();
      aktSchritt++;
      if(aktSchritt % 1000 == 0)
        System.out.println("Schritt:" + aktSchritt +" von " + schritteError + " Fehler:" + aktError );
    }
  }

  public int lernSchritt()
  {
    aktError = fError();
    for ( int j = 0; j < musterAnz; j++ )
    {
      propagation( j );
      backpropagation( j );
    }
    aktError = fError();
    aktSchritt++;
    //if(aktSchritt % 1000 == 0)
    //  System.out.println("Schritt:" + aktSchritt +" von " + schritteError + " Fehler:" + aktError );
    return aktSchritt;
  }

  private double fError()
  {
    double summe = 0.0;
    double h;
    for ( int i = 0; i < musterAnz; i++ )
    {
      propagation( i );
      for ( int j = 0; j < outputAnz; j++ )
      {
        h = layerTarget[i][j] - layerOutput[j];
        summe += h * h;
      }
    }
    return summe / 2.0;
  }

  private double zufallsWert()
  {
    return r.nextDouble() * 0.6 - 0.3;
  }

  private char zahl2grau( double zahl )
  {
    if ( zahl > 0.9 )
      return '*';
    if ( zahl < 0.1 )
      return ' ';
    return '?';
  }

  private double grau2zahl( char zeichen )
  {
    switch ( zeichen )
    {
      case '*':
        return 1.0;
      case ' ':
        return 0.0;
      default:
        return 0.5;
    }
  }

  private double[][] grau2doubleFeld( char[][] feld )
  {
    double[][] doubleFeld = new double[feld.length][INPUT_MAX];
    for ( int i = 0; i < feld.length; i++ )
      for ( int j = 0; j < feld[0].length; j++ )
        doubleFeld[i][j] = grau2zahl( feld[i][j] );
    return doubleFeld;
  }

  private double sigmoid( double x )
  {
    return 1.0 / ( 1.0 + Math.exp( -x ) );
  }

  private void propagation( int p )
  {
    double summe;
    for ( int i = 0; i < hiddenAnz; i++ )
    {
      summe = 0.0;
      for ( int j = 0; j < inputAnz; j++ )
        summe += wInputHidden[i][j] * layerInput[p][j];
      layerHidden[i] = sigmoid( summe + offHidden[i] );
    }
    for ( int i = 0; i < outputAnz; i++ )
    {
      summe = 0.0;
      for ( int j = 0; j < hiddenAnz; j++ )
        summe += wHiddenOutput[i][j] * layerHidden[j];
      layerOutput[i] = sigmoid( summe + offOutput[i] );
    }
  }

  private void backpropagation( int p )
  {
    double summe, h;
    double[] y_hidden = new double[hiddenAnz];
    double[] y_output = new double[outputAnz];
    for ( int i = 0; i < outputAnz; i++ )
    {
      h = layerOutput[i];
      y_output[i] = ( layerTarget[p][i] - h ) * h * ( 1.0 - h );
    }
    for ( int i = 0; i < hiddenAnz; i++ )
    {
      summe = 0.0;
      for ( int j = 0; j < outputAnz; j++ )
      {
        wDiffHiddenOutput[j][i] = eta * y_output[j] * layerHidden[i] +
            alpha * wDiffHiddenOutput[j][i];
        wHiddenOutput[j][i] += wDiffHiddenOutput[j][i];
        summe += y_output[j] * wHiddenOutput[j][i];
      }
      y_hidden[i] = summe * layerHidden[i] * ( 1 - layerHidden[i] );
    }
    for ( int i = 0; i < outputAnz; i++ )
    {
      diffOffOutput[i] = eta * y_output[i] + alpha * diffOffOutput[i];
      offOutput[i] += diffOffOutput[i];
    }

    for ( int i = 0; i < inputAnz; i++ )
    {
      for ( int j = 0; j < hiddenAnz; j++ )
      {
        wDiffInputHidden[j][i] = eta * y_hidden[j] * layerInput[p][i] +
            alpha * wDiffInputHidden[j][i];
        wInputHidden[j][i] += wDiffInputHidden[j][i];
      }
    }
    for ( int i = 0; i < hiddenAnz; i++ )
    {
      diffOffHidden[i] = eta * y_hidden[i] + alpha * diffOffHidden[i];
      offHidden[i] += diffOffHidden[i];
    }
  }

  public void wissenLesen()
  {
	wissenLesen( wissenDateiName );  
  }

  public void wissenLesen( String dateiname )
  {
    FileReader rd = null;
    BufferedReader br = null;
    String zeile = "";
    String[] buffer = null;

    try
    {
      rd = new FileReader( dateiname );
      br = new BufferedReader( rd );

      for ( int i = 0; i < layerTarget.length; i++ )
      {
        zeile = br.readLine();
        buffer = zeile.split( ";" );
        for ( int k = 0; k < buffer.length; k++ )
          layerTarget[i][k] = Double.parseDouble( buffer[k] );
      }
      for ( int i = 0; i < layerInput.length; i++ )
      {
        zeile = br.readLine();
        buffer = zeile.split( ";" );
        for ( int k = 0; k < buffer.length; k++ )
          layerInput[i][k] = Double.parseDouble( buffer[k] );
      }
      for ( int i = 0; i < wInputHidden.length; i++ )
      {
        zeile = br.readLine();
        buffer = zeile.split( ";" );
        for ( int k = 0; k < buffer.length; k++ )
          wInputHidden[i][k] = Double.parseDouble( buffer[k] );
      }
      for ( int i = 0; i < wDiffInputHidden.length; i++ )
      {
        zeile = br.readLine();
        buffer = zeile.split( ";" );
        for ( int k = 0; k < buffer.length; k++ )
          wDiffInputHidden[i][k] = Double.parseDouble( buffer[k] );
      }
      for ( int i = 0; i < wHiddenOutput.length; i++ )
      {
        zeile = br.readLine();
        buffer = zeile.split( ";" );
        for ( int k = 0; k < buffer.length; k++ )
          wHiddenOutput[i][k] = Double.parseDouble( buffer[k] );
      }
      for ( int i = 0; i < wDiffHiddenOutput.length; i++ )
      {
        zeile = br.readLine();
        buffer = zeile.split( ";" );
        for ( int k = 0; k < buffer.length; k++ )
          wDiffHiddenOutput[i][k] = Double.parseDouble( buffer[k] );
      }
      zeile = br.readLine();
      buffer = zeile.split( ";" );
      for ( int i = 0; i < buffer.length; i++ )
        layerHidden[i] = Double.parseDouble( buffer[i] );
      zeile = br.readLine();
      buffer = zeile.split( ";" );
      for ( int i = 0; i < buffer.length; i++ )
        offHidden[i] = Double.parseDouble( buffer[i] );
      zeile = br.readLine();
      buffer = zeile.split( ";" );
      for ( int i = 0; i < buffer.length; i++ )
        diffOffHidden[i] = Double.parseDouble( buffer[i] );
      zeile = br.readLine();
      buffer = zeile.split( ";" );
      for ( int i = 0; i < buffer.length; i++ )
        layerOutput[i] = Double.parseDouble( buffer[i] );
      zeile = br.readLine();
      buffer = zeile.split( ";" );
      for ( int i = 0; i < buffer.length; i++ )
        offOutput[i] = Double.parseDouble( buffer[i] );
      zeile = br.readLine();
      buffer = zeile.split( ";" );
      for ( int i = 0; i < buffer.length; i++ )
        diffOffOutput[i] = Double.parseDouble( buffer[i] );
    }
    catch ( IOException e )
    {
      System.err.println( "IO-Fehler beim Öffnen/Lesen " + e.getMessage() );
      System.err.println( "Dateiname: " + dateiname );
    }
    catch ( Exception e )
    {
      System.err.println( "allgemeiner Fehler beim Lesen " + e.getMessage() );
      System.err.println( "Dateiname: " + dateiname );
    }
    finally
    {
      try
      {
        br.close();
      }
      catch ( IOException e )
      {
        System.err.println( "IO-Fehler beim Close " + e.getMessage() );
        System.err.println( "Dateiname: " + dateiname );
      }
    }
  }

  public void wissenSchreiben()
  {
	wissenSchreiben( wissenDateiName );  
  }

  public void wissenSchreiben( String dateiname )
  {
    FileWriter wr = null;
    BufferedWriter bw = null;
    String zeile = "";

    try
    {
      wr = new FileWriter( dateiname );
      bw = new BufferedWriter( wr );

      for ( int i = 0; i < layerTarget.length; i++ )
      {
        for ( int k = 0; k < layerTarget[0].length; k++ )
          zeile = zeile + layerTarget[i][k] + ";";
        bw.write( zeile );
        bw.newLine();
        zeile = "";
      }
      for ( int i = 0; i < layerInput.length; i++ )
      {
        for ( int k = 0; k < layerInput[0].length; k++ )
          zeile = zeile + layerInput[i][k] + ";";
        bw.write( zeile );
        bw.newLine();
        zeile = "";
      }
      for ( int i = 0; i < wInputHidden.length; i++ )
      {
        for ( int k = 0; k < wInputHidden[0].length; k++ )
          zeile = zeile + wInputHidden[i][k] + ";";
        bw.write( zeile );
        bw.newLine();
        zeile = "";
      }
      for ( int i = 0; i < wDiffInputHidden.length; i++ )
      {
        for ( int k = 0; k < wDiffInputHidden[0].length; k++ )
          zeile = zeile + wDiffInputHidden[i][k] + ";";
        bw.write( zeile );
        bw.newLine();
        zeile = "";
      }
      for ( int i = 0; i < wHiddenOutput.length; i++ )
      {
        for ( int k = 0; k < wHiddenOutput[0].length; k++ )
          zeile = zeile + wHiddenOutput[i][k] + ";";
        bw.write( zeile );
        bw.newLine();
        zeile = "";
      }
      for ( int i = 0; i < wDiffHiddenOutput.length; i++ )
      {
        for ( int k = 0; k < wDiffHiddenOutput[0].length; k++ )
          zeile = zeile + wDiffHiddenOutput[i][k] + ";";
        bw.write( zeile );
        bw.newLine();
        zeile = "";
      }
      for ( int i = 0; i < layerHidden.length; i++ )
        zeile = zeile + layerHidden[i] + ";";
      bw.write( zeile );
      bw.newLine();
      zeile = "";
      for ( int i = 0; i < offHidden.length; i++ )
        zeile = zeile + offHidden[i] + ";";
      bw.write( zeile );
      bw.newLine();
      zeile = "";
      for ( int i = 0; i < diffOffHidden.length; i++ )
        zeile = zeile + diffOffHidden[i] + ";";
      bw.write( zeile );
      bw.newLine();
      zeile = "";
      for ( int i = 0; i < layerOutput.length; i++ )
        zeile = zeile + layerOutput[i] + ";";
      bw.write( zeile );
      bw.newLine();
      zeile = "";
      for ( int i = 0; i < offOutput.length; i++ )
        zeile = zeile + offOutput[i] + ";";
      bw.write( zeile );
      bw.newLine();
      zeile = "";
      for ( int i = 0; i < diffOffOutput.length; i++ )
        zeile = zeile + diffOffOutput[i] + ";";
      bw.write( zeile );
      bw.newLine();
      zeile = "";
    }

    catch ( IOException e )
    {
      System.err.println( "IO-Fehler beim Öffnen/Schreiben " + e.getMessage() );
      System.err.println( "Dateiname: " + dateiname );
    }
    catch ( Exception e )
    {
      System.err.println( "allgemeiner Fehler beim Schreiben " + e.getMessage() );
      System.err.println( "Dateiname: " + dateiname );
    }
    finally
    {
      try
      {
        bw.close();
      }
      catch ( IOException e )
      {
        System.err.println( "IO-Fehler beim Close " + e.getMessage() );
        System.err.println( "Dateiname: " + dateiname );
      }
    }
  }

  public void anzeigen()
  {
    anzeigenLayerTarget();
    anzeigenLayerInput();
    anzeigenLayerHidden();
    anzeigenLayerOutput();
    anzeigenOffHidden();
    anzeigenDiffOffHidden();
    anzeigenOffOutput();
    anzeigenDiffOffOutput();
    anzeigenWInputHidden();
    anzeigenWDiffInputHidden();
    anzeigenWHiddenOutput();
    anzeigenWDiffHiddenOutput();
    anzeigenHamming();
  }

  private void anzeigenLayerTarget()
  {
    for ( int i = 0; i < layerTarget.length; i++ )
    {
      System.out.print( "layerTarget[" + i + "]=" );
      for ( int k = 0; k < layerTarget[0].length; k++ )
        System.out.print( layerTarget[i][k] + "," );
      System.out.println();
    }
  }

  private void anzeigenLayerInput()
  {
    for ( int i = 0; i < layerInput.length; i++ )
    {
      System.out.print( "layerInput[" + i + "]=                 " );
      for ( int k = 0; k < layerInput[0].length; k++ )
        System.out.print( layerInput[i][k] + "," );
      System.out.println();
    }
  }

  private void anzeigenLayerHidden()
  {
    System.out.print( "LayerHidden= " );
    for ( int i = 0; i < layerHidden.length; i++ )
      System.out.print( layerHidden[i] + "," );
    System.out.println();
  }

  private void anzeigenOffHidden()
  {
    System.out.print( "offHidden= " );
    for ( int i = 0; i < offHidden.length; i++ )
      System.out.print( offHidden[i] + "," );
    System.out.println();
  }

  private void anzeigenDiffOffHidden()
  {
    System.out.print( "diffOffHidden= " );
    for ( int i = 0; i < diffOffHidden.length; i++ )
      System.out.print( diffOffHidden[i] + "," );
    System.out.println();
  }

  private void anzeigenLayerOutput()
  {
    System.out.print( "layerOutput=" );
    for ( int i = 0; i < layerOutput.length; i++ )
      System.out.print( layerOutput[i] + "," );
    System.out.println();
  }

  private void anzeigenOffOutput()
  {
    System.out.print( "offOutput=" );
    for ( int i = 0; i < offOutput.length; i++ )
      System.out.print( offOutput[i] + "," );
    System.out.println();
  }

  private void anzeigenDiffOffOutput()
  {
    System.out.print( "diffOffOutput=" );
    for ( int i = 0; i < diffOffOutput.length; i++ )
      System.out.print( diffOffOutput[i] + "," );
    System.out.println();
  }

  private void anzeigenWInputHidden()
  {
    for ( int i = 0; i < wInputHidden.length; i++ )
    {
      System.out.print( "wInputHidden[" + i + "]=" );
      for ( int k = 0; k < wInputHidden[0].length; k++ )
        System.out.print( wInputHidden[i][k] + "," );
      System.out.println();
    }
  }

  private void anzeigenWDiffInputHidden()
  {
    for ( int i = 0; i < wDiffInputHidden.length; i++ )
    {
      System.out.print( "wDiffInputHidden[" + i + "]=" );
      for ( int k = 0; k < wDiffInputHidden[0].length; k++ )
        System.out.print( wDiffInputHidden[i][k] + "," );
      System.out.println();
    }
  }

  private void anzeigenWHiddenOutput()
  {
    for ( int i = 0; i < wHiddenOutput.length; i++ )
    {
      System.out.print( "wHiddenOutput[" + i + "]=" );
      for ( int k = 0; k < wHiddenOutput[0].length; k++ )
        System.out.print( wHiddenOutput[i][k] + "," );
      System.out.println();
    }
  }

  private void anzeigenWDiffHiddenOutput()
  {
    for ( int i = 0; i < wDiffHiddenOutput.length; i++ )
    {
      System.out.print( "wDiffHiddenOutput[" + i + "]=" );
      for ( int k = 0; k < wDiffHiddenOutput[0].length; k++ )
        System.out.print( wDiffHiddenOutput[i][k] + "," );
      System.out.println();
    }
  }

  private void anzeigenHamming()
  {
    getHamming();
    getHammingMin();
    System.out.println( "binärer Abstand     Lernmuster" );
    System.out.print( "             " );
    for ( int i = 0; i < musterAnz; i++ )
      System.out.print( "    " + i );
    System.out.println();
    for ( int i = 0; i < testAnz; i++ )
    {
      System.out.print( "Testmuster: " + i + "   " );
      for ( int j = 0; j < musterAnz; j++ )
        System.out.printf( "%02d   ", musterHamming[i][j] );
      System.out.println(" Minimum bei: " + musterHammingMin[i]);
    }
  }

  public void analyse()
  {
    System.out.println();
    System.out.println( "Analyse des Neuronalen Netzes" );
    System.out.println();
    System.out.println( "Ausgabe des Erkennungs-Verktors" );
    System.out.print( "erkannte Muster:" );
    for ( int i = 0; i < getTestAnz(); i++ )
    {
      System.out.print( "[" + i + "]=" + ergebnisIdent[i] + ", " );
    }
    System.out.println();
    
    System.out.println();
    System.out.print( "Ausgabe der vervollständigten-Muster(Double)" );
    for ( int i = 0; i < getTestAnz(); i++ )
    {
      System.out.println();
      System.out.print( "vervollständigtes Testmuster[" + i + "]=" );

      for ( int j = 0; j < getInputAnz(); j++ )
      {
        System.out.print( ergebnisOutput[i][j] + " " );
      }
    }
    System.out.println();
 
    System.out.println();
    System.out.print( "Ausgabe der vervollständigten-Muster(Char)" );
    for ( int i = 0; i < getTestAnz(); i++ )
    {
      System.out.println();
      System.out.print( "vervollständigtes Testmuster[" + i + "]=" );

      for ( int j = 0; j < getInputAnz(); j++ )
      {
        System.out.print( ergebnisGrau[i][j] );
      }
    }
    System.out.println();
    
    System.out.println();
    System.out.println( "binärer Abstand     Lernmuster" );
    System.out.print( "             " );
    for ( int i = 0; i < getMusterAnz(); i++ )
      System.out.print( "    " + i );
    System.out.println();
    for ( int i = 0; i < getTestAnz(); i++ )
    {
      System.out.print( "Testmuster: " + i + "   " );
      for ( int j = 0; j < getMusterAnz(); j++ )
        System.out.printf( "%02d   ", musterHamming[i][j] );
      System.out.println(" Minimum ist bei: " + musterHammingMin[i]);
    }
  }
}