﻿package test20150301;

import Neuronen.Neuronen;

public class ErkennenPerceptron25
{
  private static int        inputAnz       = 25;
  private static int        hiddenAnz      = 10;
  private static int        musterAnz      = 8;
  private static int        testAnz        = 8;

  private static double[][] feldMuster;
  private static double[][] feldTest;
  private static char[][]   grauMuster;
  private static char[][]   grauTest;
  private static int[]      feldIdent;
  private static double[][] feldOutput;
  private static char[][]   grauOutput;
  private static int[][]    feldHamming;

  private static String            c72C0          = "00000000000000000000" +
                                               "00000000000000000000" +
                                               "00000000000000000000" +
                                               "000000000000";
  private static String            c72C1          = "11111111111111111111" +
                                               "11111111111111111111" +
                                               "11111111111111111111" +
                                               "111111111111";

  private static String[]          constantTarget =
                                           {
                                           "110001110011000110001101100000000000" + c72C0,
                                           "010010101111110101001000000000000000" + c72C0,
                                           "101011001011100100011001000000000000" + c72C0,
                                           "011010001100110001011001000000000000" + c72C0,
                                           "001110001100111001110010011111111111" + c72C1,
                                           "101101010000001010110111111111111111" + c72C1,
                                           "010100110100011011100110111111111111" + c72C1,
                                           "100101110011001110100110111111111111" + c72C1 };

  private static Neuronen   nn             = new Neuronen( inputAnz, hiddenAnz, musterAnz, testAnz );

  public static void main( String[] args )
  {
    System.out.println( "Vor dem Initialisieren, Checksumme Neuronales Netz: " + nn.getCheckSumme() );
    netzInit();

    System.out.println( "Kontrollausgabe des Neuronalen Netzes" );
    //nn.anzeigen();
    
    System.out.println( "Nach dem Initialisieren, Checksumme Neuronales Netz: " + nn.getCheckSumme() );

    StopUhr stopUhr = new StopUhr();
    stopUhr.start( "Lernen" );
    lernen1();
    //lernen2();
    stopUhr.stop();
    System.out.println( "Nach dem Lernen, Checksumme Neuronales Netz: " + nn.getCheckSumme() );
    nn.wissenSchreiben();

    nn.initZufall();
    System.out.println( "Nach dem Zufällig Neu befüllen, Checksumme Neuronales Netz: " + nn.getCheckSumme() );
    //nn.anzeigen();

    nn.initLeer();
    System.out.println( "Nach dem Leer Neu befüllen, Checksumme Neuronales Netz: " + +nn.getCheckSumme() );
    //nn.anzeigen();

    nn.wissenLesen();
    System.out.println( "Nach dem Zurücklesen der Wissensbasis, Checksumme Neuronales Netz: "
        + nn.getCheckSumme() );

    lernen2();
    nn.erkennen();

    nn.analyse();
    
    System.out.println();
    System.out.println( "OK" );
  }

  private static void lernen1()
  {
    System.out.println("vor Lernen1  Schritt:" + nn.getAktSchritt() +" von " + nn.getSchritteError() + " Fehler:" + nn.getAktError() );
    nn.lernSchleife();
    System.out.println("nach Lernen1 Schritt:" + nn.getAktSchritt() +" von " + nn.getSchritteError() + " Fehler:" + nn.getAktError() );
  }

  private static void lernen2()
  {
    nn.setAktSchritt( 0 );
    nn.lernSchritt();
    System.out.println("vor Lernen2 Schritt:" + nn.getAktSchritt() +" von " + nn.getSchritteError() + " Fehler:" + nn.getAktError() );
    while (nn.getAktError() > nn.getStopError() && nn.getAktSchritt() < nn.getSchritteError())
    {
      nn.lernSchritt();
      if (nn.getAktSchritt() % 1000 == 0)
        System.out.println("im Lernen2 Schritt:" + nn.getAktSchritt() +" von " + nn.getSchritteError() + " Fehler:" + nn.getAktError() );
    }
    System.out.println("nach Lernen2 Schritt:" + nn.getAktSchritt() +" von " + nn.getSchritteError() + " Fehler:" + nn.getAktError() );
 }

  private static void netzInit()
  {
    feldMuster = new double[musterAnz][inputAnz];
    feldTest = new double[testAnz][inputAnz];
    grauMuster = new char[musterAnz][inputAnz];
    grauTest = new char[testAnz][inputAnz];

    for ( int i = 0; i < musterAnz; i++ )
      for ( int j = 0; j < inputAnz; j++ )
      {
        if ( constantTarget[i].charAt( j ) == '0' )
        {
          feldMuster[i][j] = 0.0;
          grauMuster[i][j] = ' ';
        }
        else
        {
          feldMuster[i][j] = 1.0;
          grauMuster[i][j] = '*';
        }
      }

    for ( int i = 0; i < testAnz; i++ )
      for ( int j = 0; j < inputAnz; j++ )
      {
        if ( constantTarget[i].charAt( j ) == '0' )
        {
          feldTest[i][j] = 0.0;
          grauTest[i][j] = ' ';
        }
        else
        {
          feldTest[i][j] = 1.0;
          grauTest[i][j] = '*';
        }
      }

    //anzeigeMuster( "Muster", feldMuster );
    //anzeigeMuster( "Test", feldTest );

    anzeigeGrau( "Muster grau", grauMuster );
    anzeigeGrau( "Test grau", grauTest );

    nn.setMuster( feldMuster );
    nn.setTest( feldTest );
    
    //nn.setGrauMuster( grauMuster );
    //nn.setGrauTest( grauTest );

    //nn.analyse();
  }

  private static void anzeigeMuster( String was, double[][] feld )
  {
    for ( int i = 0; i < feld.length; i++ )
    {
      System.out.print( was + "[" + i + "]=" );
      for ( int j = 0; j < feld[0].length; j++ )
      {
        System.out.print( feld[i][j] + " " );
      }
      System.out.println();
    }
  }

  private static void anzeigeGrau( String was, char[][] feld )
  {
    for ( int i = 0; i < feld.length; i++ )
    {
      System.out.print( was + "[" + i + "]=" );
      for ( int j = 0; j < feld[0].length; j++ )
      {
        System.out.print( feld[i][j] );
      }
      System.out.println();
    }
  }
}
