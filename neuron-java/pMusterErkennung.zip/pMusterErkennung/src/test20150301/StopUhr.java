﻿package test20150301;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StopUhr
{
  DateFormat df = new SimpleDateFormat( "EEEE, dd.MMM yyyy HH:mm:ss,SSS" );
  private String kommentar = "";
  private long beginn, ende;

  public StopUhr()
  {
    kommentar = "Stopuhr:";
  }

  public void start()
  {
    kommentar = "";
    beginn = System.currentTimeMillis();
    System.out.println( "START  " + df.format( new Date()));
  }
    

  void start(String kommentar)
  {
    this.kommentar = kommentar;
    beginn = System.currentTimeMillis();
    System.out.println( "START " + kommentar + "  " + df.format( new Date()));
  }

  void stop()
  {
    ende = System.currentTimeMillis();

    System.out.print("STOP  ");
    if (kommentar.length() > 0)
    {
      System.out.print(kommentar + " ");
    }
    System.out.println(" " + df.format(new Date())  + "  Laufzeit: " + (ende-beginn) + "ms");
  }
}