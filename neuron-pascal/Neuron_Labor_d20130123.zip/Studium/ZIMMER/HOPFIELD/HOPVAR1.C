/*******************************************************************
 *                                                                 *
 *   ZEICHENERKENNUNG  mit dem Hopfield-Modell                     *
 *                                                                 *
 *   Bernd Schubert 88/08/01         TURBO-C  Schneider-PC         *
 *                                   Stand: 06/90                  *
 *                                                                 *
 *   erweitertes Modell, mit Hamming- u.Energieberechnung,         *
 *   erkennt Oszillieren                                           *
 *                                                                 *
 *******************************************************************/

#include <stdio.h>
#include <conio.h>

#define maxlaenge 20
#define maxanzahl  8

int Matrix[maxlaenge][maxlaenge];
int Muster[maxlaenge],Hilfe[maxlaenge],Keller[maxlaenge];
int IntMuster[maxanzahl][maxlaenge];
char *CharMuster[] = {
		    "10110111011101001001",
		    "01011001000011100011",
		    "11000101110110111100",
		    "01110110101000101110",
		    "01010010111001000101",
		    "01000100011110010011",
		    "00110001111111010100",
		    "11001011100010001010"
		     };
char ch;
int test,versuch,pos,g,konvergent,laenge=20,anzahl=4;

main() {
textcolor(WHITE);
textbackground(BLUE);
do {
  Initialisierung();
  do {
    clrscr(); for(g=0;g<anzahl;g++) Musteraus(g);
    Input(); for(g=0;g<laenge;g++) Hilfe[g]=Muster[g];
    gotoxy(77,laenge+4); printf("#"); out(4,laenge+4,"Energie: ");
    Energie();  pos=anzahl*2+24; versuch=0;
    do {
      for(g=0;g<laenge;g++) { Keller[g]=Hilfe[g]; Hilfe[g]=Muster[g]; };
      versuch++; pos+=2; Iteration(); Energie();
      konvergent=Vergleich(Hilfe,Muster);
      }
    while(!(konvergent||(Vergleich(Muster,Keller))));
    Auswertung();
    out(59,laenge+4,"noch einmal (j)/n ? "); ch=toupper(getch()); clrscr();
    }
  while(ch!='N');
  out(10,5,"Wiederholung mit anderen Lernmustern ? (n)/j ");
  ch=toupper(getch());
  }
while(ch=='J');
clrscr();
}
out (s,z,string) int s,z; char string[]; {
  gotoxy(s,z); printf("%s",string);
}
Codierung() {
  int e,f;
  for(e=0;e<anzahl;e++)
    for(f=0;f<laenge;f++) IntMuster[e][f]=CharMuster[e][f]-'0';
} /* Codierung */
int Hamming(e)  int e; {
  int i,h=0;
  for(i=0;i<laenge;i++) if(IntMuster[e][i]!=Muster[i]) h++;
  return h;
} /* Hamming */
Abstand() {
  int l;
  for(l=0;l<anzahl;l++) {
    gotoxy(4*(l+1)-2,laenge+2); printf("(%d)",Hamming(l));
  }
} /* Abstand */
Lernmatrix() {
  int i,j,e;
  clrscr();
  for(i=0;i<laenge;i++) {
    for(j=0;j<laenge;j++) {
      Matrix[i][j]=0;
      if(i!=j) { for(e=0;e<anzahl;e++)
        Matrix[i][j]+=(2*IntMuster[e][i]-1)*(2*IntMuster[e][j]-1);
      };
      gotoxy(2*j+1,i+2); printf("%2d",Matrix[i][j]);
    }
  }
  gotoxy(1,1); ch=getch();
} /* Lernmatrix */
Input() {
  int k,i;
  for(i=0;i<laenge;i++) {
    out(2*anzahl+19,i+2,"BIT:");
    do k=getch()-'0'; while((k<0)||(k>1));
    Muster[i]=k;   printf("%d",k);
  }
} /* Input */
Iteration() {
  int i,j,summe;
  for(i=0;i<laenge;i++) {
    summe=-anzahl*(1-Hilfe[i]);
    for(j=0;j<laenge;j++) summe+=Matrix[i][j]*(2*Hilfe[j]-1);
    Muster[i]=summe>0 ? 1:0;
    gotoxy(pos,i+2); printf("%d",Muster[i]);
  }
} /* Iteration */
Vergleich(vMuster,hMuster) int vMuster[maxlaenge],hMuster[maxlaenge]; {
  int i;
  for (i=0;i<laenge;i++) if(vMuster[i]!=hMuster[i]) return 0;
  return 1;
} /* Vergleich */
Musteraus(g) int g; {
  int i;
  for(i=0;i<laenge;i++) {
    gotoxy(4*(g+1)-1,i+2); printf("%d",IntMuster[g][i]);
  }
} /* Musteraus */
Auswertung() {
  int e;
  gotoxy(22,laenge+4); clreol(); printf("### ");
  if(konvergent==0) printf("oszillierend  ");
  else {
    for(e=0; (e<anzahl) && (Hamming(e)>0); e++);
    if (e<anzahl) printf("erkannt Muster: %d ",e+1);
    else printf("kein Muster erkennbar  ");
  };
  printf("###");
} /* Auswertung */
Energie() {
  int i,j,summe;
  summe=0;
  for(i=0;i<laenge;i++) {
    for(j=0;j<laenge;j++) {
      if(i!=j) summe+=(Matrix[i][j]*Hilfe[i]*Muster[j]);
    };
  };
  gotoxy(13,laenge+4); printf("%2d   ",-summe/2);
  gotoxy(1,laenge+2); clreol(); Abstand(); gotoxy(79,laenge+4); ch=getch();
} /* Energie */
eingl() {
  int ch;
  gotoxy(57,6); clreol(); test=laenge;
  do { ch=getch()-'0'; if (ch==-35) return; } while((ch<1)||(ch>9));
  test=ch; printf("%d",test); if (test>2) return;
  do { ch=getch()-'0'; if (ch==-35) return; } while((ch<0)||(ch>9));
  test=10*test+ch; printf("%d",ch);
}
Parameter() {
  out(13,6,"Eingabe Vektorlaenge (max. 20, derzeit:");
  printf("%2d): ",laenge); do eingl(); while(test>maxlaenge); laenge=test;
  out(13,8,"Eingabe Anzahl Lernmuster (max. 8, derzeit:");
  printf("%2d): ",anzahl);
  do {
    test=getch()-'0'; if(test==-35) test=anzahl;
    }
  while((test>maxanzahl)||(test<1)); anzahl=test;
  printf("%2d ",anzahl);
}
Initialisierung() {
  int e,f;
  clrscr();
  out(11,2,"Mustererkennung durch das H O P F I E L D - M O D E L L");
  out(11,3,"=======================================================");
  do Parameter(); while(test>maxlaenge);
  out(13,10,"Wollen Sie die Standardvektoren lernen lassen oder");
  gotoxy(13,11); printf("selbst %d",anzahl);
  printf(" zu lernende Vektoren vorgeben (S = selbst)  ");
  ch=toupper(getch()); clrscr();
  if(ch!='S') Codierung();
  else for(e=0;e<anzahl;e++) {
    Input(); for(f=0;f<laenge;f++) IntMuster[e][f]=Muster[f];
    Musteraus(e);
  };
  Lernmatrix();
}
