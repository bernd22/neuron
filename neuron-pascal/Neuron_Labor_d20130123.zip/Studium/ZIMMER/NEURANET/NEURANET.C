/*************************************************************************/
/*                                                                       */
/*    N E U R A N E T - ein Programm zum Spielen mit Neuronalen Netzen   */
/*    T.Wolf                                                  06.10.89   */
/*                                                                       */
/*************************************************************************/

#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <stdlib.h>

/* Geraetespezifische Routinen zum Aus- und Einschalten des Cursors, die */
/* fuer NEC-Personalcomputer PC-9801 ausgelegt ist. Wer diese Sequenzen  */
/* fuer seinen Computer nicht kennt, kann die Funktionsdefinitionen durch*/
/* 'printf("");' ersetzen. Das Programm funktioniert trotzdem, der Cursor*/
/* flackert nur in der Lernschleife.                                     */

#define CursorOff printf("\x1B[>5h"]);   /* 'Cursor Off' fuer NEC-Comp.  */
#define CursorOn printf("\x1B[>5l"]);    /* 'Cursor On' fuer NEC-Computer*/

/* Netzwerkabhaengige Parameter */

#define InputUnitMax    50     /* max. Anzahl der Input-Elemente         */
#define HiddenUnitMax   30     /* max. Anzahl der Hidden-Elemente        */
#define OutputUnitMax   10     /* max. Anzahl der Output-Elemente        */
#define MaxPatternAnz   25     /* Maximalzahl der Lernmuster             */

/* Grenzwerte fuer Wichtungsfaktoren */

#define Wmin        -0.30      /* Minimaler inital. Wichtungsfaktor      */
#define Wmax         0.30      /* Maximaler inital. Wichtungsfaktor      */

/* Funktionsdefinitionen */

#define f(x)       (1/(1+exp(-(x))))          /* Sigmoid-Funktion        */
#define rnd( )     ((double)rand()/0x7fff*(Wmax-Wmin)+Wmin)

/* Globale Variablen */

double OutI[MaxPatternAnz][InputUnitMax];     /*Ausgabewerte Input-Ebene */
double OutH[HiddenUnitMax];                   /*Ausgabewerte Hidden-Ebene*/
double OutO[OutputUnitMax];                   /*Ausgabewerte Output-Ebene*/
float  Target[MaxPatternAnz][OutputUnitMax];  /*Feld fuer Zielwerte      */

double w21[HiddenUnitMax][InputUnitMax];      /*Wicht.fakt. Input->Hidden*/
double dw21[HiddenUnitMax][InputUnitMax];     /*Differenz der Wicht.fakt.*/
double w32[OutputUnitMax][HiddenUnitMax];     /*Wicht.fakt.Hidden->Output*/
double dw32[OutputUnitMax][HiddenUnitMax];    /*Differenz der Wicht.fakt.*/

double Offset2[HiddenUnitMax];                /*Offset fuer Hidden-Ebene */
double dOffset2[HiddenUnitMax];               /*Differenz des Offset2    */
double Offset3[OutputUnitMax];                /*Offset fuer Output-Ebene */
double dOffset3[OutputUnitMax];               /*Differenz des Offset3    */

int    learning_pattern_no;                   /*Anzahl der Lernmuster    */
int    test_pattern_no;                       /*Anzahl der Testmuster    */
int    InputUnitAnz;                          /*aktuelle InputUnit-Zahl  */
int    HiddenUnitAnz;                         /*aktuelle HiddenUnit-Zahl */

int    OutputUnitAnz;                         /*aktuelle OutputUnit-Zahl */
float  Eta;                      /*Einflussfaktor fuer neues Wissen      */
float  Alpha;                    /*Einflussfaktor fuer altes Wissen      */
float  StopError;                /*Fehlerwert fuer Abbruch des Lernens   */

FILE   *learn;                               /*Ausg.file mit Wissensbasis*/
FILE   *protok;                              /*Protokollfile des Lernens */

#define ESC 27
#define OFF 0
#define ON !OFF

int    fast_flg = OFF;           /*Flag fuer Abfrageunterdrueckung */

/* Funktiondeklarationen */

void  propagation(int);                    /*Neural-Net-Berechnung       */
void  back_propagation(int);        /*Korrektur der Wicht.faktoren       */
void  status(int);            /*Berechnung und Anzeige Neural-Output     */
void  fstatus(int);           /*wie 'status' aber mit Fileprotokoll      */
void  read_muster(char *name);   /*Lesen der Eingabemuster von Disk      */
void  read_learn(void);            /*Lesen einer alten Wissensbasis      */
void  write_learn(char *name);   /*Schreiben einer neuen Wissensbasis    */
void  initialize(char *zahl);  /*Initialisieren der Wichtungsfaktoren    */

main(int argc,char *argv[])          /*Start des Hauptprogramms          */
{
 int  i,j,k;                                 /*Schleifenvariablen        */
 char filename[30];                          /*Name des Arbeitsfiles     */
 char ss[80];                                /*Arbeitsstring             */
 double AktError;                            /*aktueller Fehlerwert      */
 char c;
 char *ptr;

 clrscr();
 printf("N E U R A N E T - Neuronale Netze zum Ausprobieren\n");
 printf("--------------------------------------------------\n");
 printf("T.Wolf                                    06.10.89\n\n\n");

			       /*Filename fuer Mustereingabe festlegen */
 if(argc>2)
     fast_flg = ON;
 if(argc<=1)  {
     printf("File mit Lern- und Testmustern: ");
     gets(ss);
     sscanf(ss,"%s",filename);
 }
 else
     strcpy(filename,argv[1]);
 read_muster(filename);                   /*File mit Muster einlesen */

 if(argc<=2)  {
     printf("\nAlte Wissensbasis einlesen (J/N): ");
     do c = toupper(getch()); while (c!='J' && c!='N');
     printf("%c\n",c);
     if (c=='J')
	 read_learn();                    /*Altes Wissen einlesen oder */
     else  {                              /*Initial. der Zufallszahlenfolge */
	    printf("Zufallszahl: ");
	    gets(ss);
	    initialize(ss);
     }
 }
  else  {
      strcpy(ss,argv[2]);
      initialize(ss);                     /*Initial. der Zufallszahlenfolge */
  }

  ptr = strchr(filename,'.');
  if (ptr!= NULL)
     filename[ptr-filename]='\0';
  strcpy(ss,filename); strcat(filename,".TXT");      /*Protokollfile */

  if (fast_flg==OFF)  {
     printf("Protokollfile anlegen (J/N): ");
     do c = toupper(getch()); while (c!='J' && c!='N');
     printf("%c\n",c);
     if (c=='N')
	strcpy(filename,"NUL");
  }

  if((protok=fopen(filename,"w"))==NULL)  {
      fprintf(stderr,"%s : File Open Error !!\n",filename);
      exit(-1);
  }

  printf("\n\n---- Ausgabedaten vor Start des Lernprozesses ----\n");
  printf(" Must.");
  for (i=1; i<=OutputUnitAnz; printf(" Ausg%d",i++));
  printf("\n");

	 /*Berechnung und Anzeige der Ausgabewerte fuer Lernmuster */
  for(AktError=0.0, i=0; i<learning_pattern_no; i++)  {
      status(i);
      for(j=0; j<OutputUnitAnz; j++)
	  AktError += pow(Target[i][j] - OutO[j], 2.0);
  }
  AktError /= 2;
  printf("Aktueller Fehler:  %.4f\n",AktError);
  fprintf(protok,"F %.4f\n",AktError);

  if (fast_flg == OFF)  {
      printf("\nFuer Start des Lernens druecke beliebige Taste !");
      getch();
  }
				 /*Start des Lernprozesses */
  clrscr();
  printf(" Num. Must.");
  for (i=1; i<=OutputUnitAnz; printf(" Ausg%d",i++));
  /* CursorOff */ ; printf("\n");

  for(i=0; AktError>StopError; )  {        /*Schleife des Lernens */
      if (learning_pattern_no <=20)  {
	 gotoxy(1,2);
      }
      for(j=0; j<learning_pattern_no; j++)  {
	 propagation(j);
	 back_propagation(j);
      }
      for(AktError=0.0, j=0; j<learning_pattern_no; j++)  {
	  printf("%4d", ++i);
	  status(j);
	  for(k=0; k<OutputUnitAnz; k++)
	      AktError+=pow(Target[j][k]-OutO[k],2.0);
      }
      AktError/=2;
      printf("\nAktueller Fehler: %.4f",AktError);
      printf("\t\t\t\t(Abbruch mit ESC)\n");
      fprintf(protok, "%d \n",i);
      fprintf(protok,"F %.4f\n",AktError);
      if (kbhit() && getch() == ESC)
	 break;                         /*Abbruch mit Taste ESC moeglich */
  }

  /*CursorOn;*/
  printf("\n\n---- Nach Abschluss des Lernprozesses----\n");
  printf("  Must.");
  for (i=1; i<=OutputUnitAnz; printf(" Ausg%d", i++));
  printf("\n");

  fprintf(protok, "\tMuster");
  for (i=1; i<=OutputUnitAnz; fprintf(protok, "\tAusg.%d", i++));
  fprintf(protok, "\n");

  for (i=0; i<learning_pattern_no + test_pattern_no; i++)
      fstatus(i);

  fprintf(protok, "\nWeightfunction w21:\n");      /*Ausgabeprotokoll */
  for(i=0; i<InputUnitAnz; i++)  {                 /*der Wichtungs-   */
      for(j=0; j<HiddenUnitAnz; j++)               /*faktoren         */
	  fprintf(protok, "%7.3f",w21[j][i]);      /*w21 und w32      */
      fprintf(protok,"\n");
  }
  fprintf(protok,"\nWeightfunction w32\n");
  for(i=0; i<OutputUnitAnz; i++)  {
      for(j=0; j<HiddenUnitAnz; j++)
	  fprintf(protok, "%7.3f", w32[i][j]);
      fprintf(protok, "\n");
  }
  fprintf(protok, "\nOffset2:\n");                /*Ausgabeprotokoll  */
  for(i=0; i<HiddenUnitAnz; i++)                  /*der Offsetwerte   */
      fprintf(protok, "%7.3f",Offset2[i]);        /*Offset2 und       */
  fprintf(protok, "\n");                          /*offset3           */

  fprintf(protok, "\nOffset3:\n");
  for(i=0; i<OutputUnitAnz; i++)
      fprintf(protok, "%7.3f",Offset3[i]);
  fprintf(protok, "\n");
  fclose(protok);

  printf("\nNeue Wissensbasis ausgeben (J/N): ");
  do c = toupper(getch()); while (c!='J' && c!='N');
  printf("%c\n",c);
  if (c=='J')  {
      strcpy(filename,ss); strcat(filename,".LRN");  /*Neue Wissensbasis */
      write_learn(filename);                         /*ausgeben          */
  }
  printf("\n\n--- Programmende ---\n");
}

/*************************************************************************/
/* Berechnung der Neural Net Ausgabewerte               propagation(p)   */
/*************************************************************************/

void propagation(int p)                  /* p ist die Nummer des Musters */
{
  int    i,j;
  double sum;
		     /* Berechnung der Ausgabewerte der Hiddenebene      */
  for(i=0; i<HiddenUnitAnz; i++)  {
      for (sum=0, j=0; j<InputUnitAnz; j++)
	   sum += w21[i][j] * OutI[p][j];
      OutH[i] = f(sum + Offset2[i]);
  }
		     /* Berechnung der Ausgabewerte der Outputebene      */
  for(i=0; i<OutputUnitAnz; i++)  {
      for(sum=0, j=0; j<HiddenUnitAnz; j++)
	  sum += w32[i][j] * OutH[j];
      OutO[i] = f(sum + Offset3[i]);
  }
}

/*************************************************************************/
/* Korrektur der Wichtungsfaktoren und Offsetwerte   back_propagation(p) */
/*************************************************************************/

void back_propagation(int p)
{
  int    i,j;
  double d2[HiddenUnitMax];
  double d3[OutputUnitMax];
  double sum;
			   /* Berechnung des Fehlerwertes                */
  for(i=0; i<OutputUnitAnz; i++)
      d3[i] = (Target[p][i] - OutO[i]) * OutO[i] * (1-OutO[i]);

			   /* Korrektur der Wichtungsfaktoren w32        */
  for(i=0; i<HiddenUnitAnz; i++)  {
      for(sum=0, j=0; j<OutputUnitAnz; j++)  {
	  dw32[j][i] = Eta*d3[j]*OutH[i] + Alpha*dw32[j][i];
	  w32[j][i] += dw32[j][i];
	  sum       += d3[j] * w32[j][i];
      }
      d2[i] = sum * OutH[i] * (1-OutH[i]);
  }
  for(i=0; i<OutputUnitAnz; i++)  {          /* Korrektur des Offset3    */
      dOffset3[i] = Eta*d3[i] + Alpha*dOffset3[i];
      Offset3[i] += dOffset3[i];
  }
			   /* Korrektur der Wichtungsfaktoren w21        */
  for(i=0; i<InputUnitAnz; i++)
      for (j=0; j<HiddenUnitAnz; j++)  {
	   dw21[j][i] = Eta*d2[j]*OutI[p][i] + Alpha*dw21[j][i];
	   w21[j][i] += dw21[j][i];
      }
  for(i=0; i<HiddenUnitAnz; i++)  {         /* Korrektur des Offset2     */
      dOffset2[i] = Eta*d2[i] + Alpha*dOffset2[i];
      Offset2[i] += dOffset2[i];
  }
}

/*************************************************************************/
/* Berechnung und Anzeige der Ausgabewerte                    status(p)  */
/*************************************************************************/

void status(int p)
{
  int i;

  printf(" %2d -> ",p+1);
  propagation(p);
  for(i=0; i<OutputUnitAnz; i++)  {
      printf(" %5.2f", OutO[i]);
  }
  fputc('\n', stdout);
}

/*************************************************************************/
/* Berechnung und Anzeige der Ausgabewerte und Protokollfile  fstatus(p) */
/*************************************************************************/

void fstatus(int p)
{
  int i;

  printf(" %2d -> ", p+1);
  fprintf(protok, "\t%2d ->",p+1);
  propagation(p);
  for(i=0; i<OutputUnitAnz; i++)  {
      printf(" %5.2f",OutO[i]);
      fprintf(protok,"\t%5.3f", OutO[i]);
  }
  fputc('\n',stdout);
  fputc('\n',protok);
}

/*************************************************************************/
/* Lesen der Lern- und Testmuster von Diskette           read_muster()   */
/*************************************************************************/

void read_muster(char *name)
{
  int   i,j;
  FILE  *fp;
  char  c;

  if (fast_flg ==ON)
     c='N';
  else  {
     printf("Anzeige der Muster (J/N): ");
     do c= toupper(getch()); while (c!='J' && c!='N');
     printf("%c\n",c);
  }
  if ((fp=fopen(name,"r"))==NULL)  {
     fprintf(stderr,"%s : File Open Error !!\n",name);
     exit(-1);
  }
			      /* Lesen der Netzwerkstruktur              */
  fscanf(fp,"%d %d %d",&InputUnitAnz,&HiddenUnitAnz,&OutputUnitAnz);
  if (InputUnitAnz>InputUnitMax || HiddenUnitAnz>HiddenUnitMax ||
      OutputUnitAnz>OutputUnitMax)  {
      fprintf(stderr,"Netzwerkstruktur ist zu gross !");
      exit(-1);
  }
  printf("\nInputelemente: %d \tHiddenelemente: %d \tOutputelemente: %d\n",
	  InputUnitAnz,HiddenUnitAnz,OutputUnitAnz);
  fscanf(fp,"%f %f %f",&StopError,&Alpha,&Eta);
  printf("StopError: %6.3f \tAlpha: %5.2f \tEta: %5.2f\n",
	  StopError,Alpha,Eta);
				      /* Lesen der Lernmuster            */
  fscanf(fp,"%d",&learning_pattern_no);
  printf("\nAnz. der Lernmuster: %d\n",learning_pattern_no);  /* Anzahl  */
  if (learning_pattern_no>MaxPatternAnz)  {
     fprintf(stderr,"Anz. der Lernpattern ist zu gross!!");
     exit(-1);
  }
  for(i=0; i<learning_pattern_no; i++)  {
      for(j=0; j<InputUnitAnz; j++)  {
	  fscanf(fp,"%lf",&OutI[i][j]);               /* Lernmuster      */
	  if (c=='J')
	     printf("%4.1f",OutI[i][j]);
      }
      if (c=='J')
	 putc('\n',stdout);
      for(j=0; j<OutputUnitAnz; j++)  {   /* zu lernender Ausgabewert    */
	 fscanf(fp,"%f",&Target[i][j]);
	 if (c=='J')
	    printf("%5.1f",Target[i][j]);
      }
      if (c=='J')
	 putc('\n',stdout);
  }
				     /* Lesen der Testmuster             */
  fscanf(fp,"%d",&test_pattern_no);                  /* Anzahl           */
  printf("Anz. der Testmuster: %d\n",test_pattern_no);
  if (learning_pattern_no+test_pattern_no>MaxPatternAnz)  {
     fprintf(stderr,"Anz. der Lern- und Testpattern ist zu gross!!");
     exit(-1);
  }
  for(i=learning_pattern_no; i<learning_pattern_no+test_pattern_no; i++)  {
      for(j=0; j<InputUnitAnz; j++)  {
	  fscanf(fp,"%lf",&OutI[i][j]);               /*Testmuster       */
	  if (c=='J')
	     printf("%4.1f",OutI[i][j]);
      }
      if (c=='J')
	 putc('\n',stdout);
  }
  fclose(fp);
}

/*************************************************************************/
/* Lesen einer alten Wissensbasis als Startwerte          read_learn()   */
/*************************************************************************/

void read_learn()
{
  FILE  *old_learn;
  char  filename[30], ss[80];
  int   i1,i2,i3,k;

  printf("File mit altem Wissen: ");
  gets(ss);
  sscanf(ss,"%s",filename);
  if((old_learn = fopen(filename, "r+b")) == NULL)  {
     fprintf(stderr,"%s : File Open Error !!\n",filename);
     exit(-1);
  }
  fread(&i1, sizeof(int),1,old_learn);
  fread(&i2,sizeof(int),1,old_learn);
  fread(&i3,sizeof(int),1,old_learn);
  if (InputUnitAnz != i1 ||
      HiddenUnitAnz!= i2 ||
      OutputUnitAnz!= i3)  {
      printf("Netzwerkstruktur <%s> stimmt nicht ueberein!", filename);
      exit(-1);
  }
  for (k=0; k<HiddenUnitAnz; k++)
      fread(&w21[k], InputUnitAnz*sizeof(double),1,old_learn);
  for (k=0; k<OutputUnitAnz; k++)
      fread(&w32[k], HiddenUnitAnz*sizeof(double),1,old_learn);
  fread(&Offset2, HiddenUnitAnz*sizeof(double),1,old_learn);
  fread(&Offset3, OutputUnitAnz*sizeof(double),1,old_learn);
  fclose(old_learn);
}

/*************************************************************************/
/* Schreiben der neuen Wissensbasis auf Disk            write_learn()    */
/*************************************************************************/

void write_learn(char *name)
{
  FILE   *learn;
  int    i,k;

  if((learn=fopen(name,"w+b"))==NULL)  {
      fprintf(stderr,"%s : File Open Error !!\n",name);
      exit(-1);
  }
  i=InputUnitAnz;  fwrite(&i,sizeof(i),1,learn);     /* Ausgabe der      */
  i=HiddenUnitAnz; fwrite(&i,sizeof(i),1,learn);     /* Netzwerkstruktur */
  i=OutputUnitAnz; fwrite(&i,sizeof(i),1,learn);     /* und der Wissens- */
						     /* basis            */
  for (k=0; k<HiddenUnitAnz; k++)
      fwrite(&w21[k], InputUnitAnz*sizeof(double),1,learn);
  for (k=0; k<OutputUnitAnz; k++)
      fwrite(&w32[k], HiddenUnitAnz*sizeof(double),1,learn);
  fwrite(&Offset2, HiddenUnitAnz*sizeof(double),1,learn);
  fwrite(&Offset3, OutputUnitAnz*sizeof(double),1,learn);
  fclose(learn);
}

/*************************************************************************/
/* Initialisieren der Wichtungsfaktoren                    initialize()  */
/*************************************************************************/

void initialize(char *zahl)
{
  int  i,j;

  srand(atoi(zahl));
  for(i=0; i<HiddenUnitAnz; i++)
      for(j=0; j<InputUnitAnz; j++)
	  w21[i][j]=rnd();
  for(i=0; i<OutputUnitAnz; i++)
      for(j=0; j<HiddenUnitAnz; j++)
	  w32[i][j]=rnd();
}

