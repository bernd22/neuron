(c) ALFWARE Bernd Schubert

Mustererkennung mit neuronalen Netzen

Lern- und Erkennungsprogramm f�r 4 Muster

Quelltext-Bibliothek aus dem Studium von Bernd Schubert